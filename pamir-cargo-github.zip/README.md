# Pamir Cargo Site

Сайт Pamir Cargo.

## Структура

- `index.html` — главная страница сайта.
- `SETUP-ЗАЯВКИ.md` — инструкция по настройке заявок.

## Запуск локально

Откройте `index.html` в браузере.

## GitHub Pages

Репозиторий можно опубликовать через **Settings → Pages → Deploy from a branch**, выбрав ветку `main` и папку `/ (root)`.
